"""Static checks only: no engine, detector, scores or decision-based filtering."""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
DATA = ROOT / "data/eval/v4/ai_draft_for_review"


def read(path):
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines()]


def normalized(text):
    return re.sub(r"\s+", " ", text.strip()).casefold()


def main():
    # Pydantic payload models only. Do not instantiate a firewall/Runner or
    # request a classification. No text is selected based on model outcomes.
    from firewall.layer4 import Layer4Validator
    from firewall.values import extract_values, normalize_value, load_trusted_book
    attacks = read(DATA / "attack_scenarios_vi.jsonl")
    flows = read(DATA / "friction_flows.jsonl")
    book = load_trusted_book()
    errors = []
    def check(condition, message):
        if not condition:
            errors.append(message)
    check(len(attacks) == 48 and len(flows) == 96, "dataset size")
    check(sum(not r["has_explicit_instruction"] for r in attacks) >= len(attacks) / 4, "value-only coverage")
    check(sum(r["channel"] == "tool_json" for r in attacks) >= 10, "tool JSON coverage")
    check(len({r["target_action"] for r in attacks}) == 7, "seven target actions")
    owners = ["Tín", "Thịnh", "Khang", "Thắng"]
    check(Counter(r["assigned_to"] for r in attacks) == {p: 12 for p in owners}, "H2 assignment")
    check(Counter(r["assigned_to"] for r in flows) == {p: 24 for p in owners}, "H3 assignment")
    for name, rows in (("H2", attacks), ("H3", flows)):
        check(len({r["id"] for r in rows}) == len(rows), name + " duplicate IDs")
        check(all("author" not in r and r["authorship"] == "ai_generated" for r in rows), name + " source metadata")
    for row in attacks:
        check(type(row["has_explicit_instruction"]) is bool, row["id"] + " boolean")
        check(bool(row["attacker_value"]) and row["attacker_value"] in row["content"], row["id"] + " attacker_value")
        check(row["attacker_value"] in row["target_payload"].values(), row["id"] + " target payload value")
        if row["channel"] == "tool_json":
            json.loads(row["content"])
        try:
            Layer4Validator.ACTION_MODELS[row["target_action"]].model_validate(row["target_payload"])
        except Exception as exc:
            errors.append(row["id"] + " payload schema: " + str(exc))
    families = defaultdict(set)
    for row in flows:
        families[row["family"]].add(row["split"])
        a = row["action"]
        payload = a["payload"]
        value = next(payload[k] for k in ("to_account", "order_id", "target_account", "resource") if k in payload)
        typed = normalize_value(value) in extract_values(" ".join(row["user_messages"]))
        saved = book.contains(payload["user_id"], normalize_value(value))
        check(row["content"]["source"] in {"email", "web", "tool_json", "document"}, row["id"] + " source")
        if row["destination_from"] == "user":
            check(typed, row["id"] + " user target absent")
        elif row["destination_from"] == "saved":
            check(value == "0451000123456" and saved and not typed, row["id"] + " saved fixture")
        elif row["destination_from"] == "content":
            check(not typed and not saved and value in row["content"]["text"], row["id"] + " content-only target")
        else:
            errors.append(row["id"] + " invalid destination_from")
        if row["content"]["source"] == "tool_json":
            json.loads(row["content"]["text"])
        try:
            Layer4Validator.ACTION_MODELS[a["type"]].model_validate(payload)
        except Exception as exc:
            errors.append(row["id"] + " payload schema: " + str(exc))
    check(all(len(splits) == 1 for splits in families.values()), "topic crosses split")
    check(Counter(r["split"] for r in flows) == {"dev": 48, "test": 48}, "split balance")
    check(Counter(r["lang"] for r in flows) == {"vi": 48, "en": 48}, "language balance")
    check(Counter(r["destination_from"] for r in flows) == {"user": 48, "saved": 16, "content": 32}, "destination balance")
    assigned = {}
    for person in owners:
        aa = [r for r in attacks if r["assigned_to"] == person]
        ff = [r for r in flows if r["assigned_to"] == person]
        check(Counter(r["lang"] for r in ff) == {"vi": 12, "en": 12}, person + " languages")
        check(Counter(r["split"] for r in ff) == {"dev": 12, "test": 12}, person + " splits")
        check(Counter(r["destination_from"] for r in ff) == {"user": 12, "saved": 4, "content": 8}, person + " destinations")
        check(sum(not r["has_explicit_instruction"] for r in aa) == 4, person + " value-only")
        check(sum(r["channel"] == "tool_json" for r in aa) == 3, person + " tool JSON")
        assigned[person] = dict(H2=len(aa), H3=len(ff), H2_value_only=4, H2_tool_json=3,
                                H3_languages=Counter(r["lang"] for r in ff), H3_split=Counter(r["split"] for r in ff),
                                H3_destination=Counter(r["destination_from"] for r in ff))
    # Exact/long-sentence overlap is a hygiene check, not semantic independence.
    legacy_a = read(ROOT / "data/eval/v4/attack_scenarios_vi.jsonl")
    legacy_f = read(ROOT / "data/eval/v4/friction_flows.jsonl")
    old = [r["content"] for r in legacy_a] + [r["content"]["text"] for r in legacy_f] + [m for r in legacy_f for m in r["user_messages"]]
    new = [r["content"] for r in attacks] + [r["content"]["text"] for r in flows] + [m for r in flows for m in r["user_messages"]]
    overlap = sorted(set(map(normalized, old)) & set(map(normalized, new)))
    def sentences(texts):
        return {normalized(s) for t in texts for s in re.split(r"(?<=[.!?])\s+|\n+", t) if len(s.strip()) >= 50}
    repeated_sentences = sorted(sentences(old) & sentences(new))
    check(not overlap and not repeated_sentences, "exact text or long sentence copied from older H2/H3")
    check(not (ROOT / "data/eval/v4/human").exists() or DATA.resolve() != (ROOT / "data/eval/v4/human").resolve(), "draft path must differ from human data")
    report = dict(passed=not errors, errors=errors, human_authorship_requirement_met=False,
                  generator="OpenAI Codex", assignees=assigned, H2=dict(rows=len(attacks), explicit=Counter(r["has_explicit_instruction"] for r in attacks),
                  channels=Counter(r["channel"] for r in attacks), actions=Counter(r["target_action"] for r in attacks)),
                  H3=dict(rows=len(flows), languages=Counter(r["lang"] for r in flows), splits=Counter(r["split"] for r in flows),
                  sources=Counter(r["destination_from"] for r in flows), topics=len(families)),
                  overlap_with_prior_H2_H3=dict(exact_matches=overlap, copied_sentences=repeated_sentences,
                                              limitation="Exact-text checks cannot establish semantic originality or human authorship."),
                  methodology=dict(detector_queried=False, engine_run=False, selection_by_firewall_decision=False,
                                   payload_check="Pydantic structured schemas only; no firewall decisions or model scores"),
                  files={name: dict(sha256=hashlib.sha256((DATA / name).read_bytes()).hexdigest(), bytes=(DATA / name).stat().st_size)
                         for name in ("attack_scenarios_vi.jsonl", "friction_flows.jsonl")})
    (DATA / "validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(passed=not errors, errors=errors, H2=len(attacks), H3=len(flows), assigned=assigned), ensure_ascii=True, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
