# Bản nháp AI H2/H3, chia phần phụ trách cho bốn thành viên

**Nguồn nội dung: OpenAI Codex. Đây không phải bộ dữ liệu do người viết và chưa đáp ứng yêu cầu môn học về dữ liệu người viết.** Trường `author` đã được bỏ theo yêu cầu. `authorship: ai_generated` ghi loại nguồn; `assigned_to` là người được phân công xem phần nháp, không phải xác nhận người đó đã viết hay duyệt nội dung.

Hai file tổng:

- `attack_scenarios_vi.jsonl`: **48 ca H2**, 32 có chỉ thị và **16 không có chỉ thị** (33,3%); **12 phản hồi tool JSON**; đủ bảy loại hành động.
- `friction_flows.jsonl`: **96 luồng H3**, 48 VI và 48 EN; 48 dev và 48 test; nguồn đích **48 user, 16 saved, 32 content**. Có 24 chủ đề; mỗi chủ đề gồm hai tình huống, mỗi tình huống có bản Việt/Anh và nằm trọn trong một split.

| Phụ trách | H2 | H3 | Thư mục phần riêng |
|---|---:|---:|---|
| Tín | 12 | 24 | `by_assignee/tin/` |
| Thịnh | 12 | 24 | `by_assignee/thinh/` |
| Khang | 12 | 24 | `by_assignee/khang/` |
| Thắng | 12 | 24 | `by_assignee/thang/` |

Trong phần mỗi người: H2 có **4 ca chỉ tráo giá trị**, **3 ca tool JSON**; H3 có **12 VI/12 EN**, **12 dev/12 test**, nguồn đích **12 user/4 saved/8 content**. `assignment.csv` là bảng phân công UTF-8 BOM để mở trong Excel. Các file JSONL đều UTF-8 không BOM, cùng schema với bộ hiện có và thêm metadata nguồn gốc.

Ví dụ metadata:

```json
{
  "assigned_to": "Tín",
  "authorship": "ai_generated",
  "review_status": "unreviewed"
}
```

## Nội dung và giới hạn

Các ngữ cảnh mới gồm phí vận chuyển đạo cụ, dịch vụ phụ đề, bộ lọc màn hình, quầy gửi hành lý, thiết bị hội nghị, giấy phép phần mềm, cổng gửi bản thu và hồ sơ công tác. Không tái sử dụng câu của bộ H2/H3 trước. Kiểm tra trùng nguyên văn/câu dài với bộ cũ đã đạt; phép kiểm tra này không chứng minh độc lập ngữ nghĩa.

- Mọi tổ chức, mã đơn, email và số tài khoản mới là giả. Người nhận saved dùng đúng fixture `0451000123456` của `demo_customer` theo yêu cầu.
- `refund.amount`/`order_value` dùng **USD**, đúng quy ước schema hiện tại; câu người dùng và chứng từ ghi rõ USD. `transfer_money.amount` dùng **VND**. Không đưa ví dụ hoàn 150.000 VND vào trường vốn dùng USD rồi vô tình tạo ca sai nghiệp vụ.
- Một số khoản hoàn hợp lệ lớn hơn 100 USD. Chúng vẫn là ca hợp lệ dù policy có thể yêu cầu duyệt; không chọn mức tiền để ép mọi ca thành ALLOW.
- Với luồng khôi phục/đặt lại mật khẩu hợp lệ, giả định bước xác minh danh tính đã thực sự hoàn tất trước hành động. Trong H2, cùng trường `identity_confirmed=true` mô tả trạng thái agent bị dụ khai báo, không phải xác minh có thật.
- **Không gọi bộ phát hiện, không lấy điểm L2, không chạy action gate và không lọc/sửa câu theo quyết định firewall.** Chỉ kiểm tra JSON, số lượng, phân công, nguồn giá trị, split theo chủ đề và schema Pydantic của payload.

## Kiểm tra và tái tạo

Từ thư mục gốc dự án:

```powershell
.\.venv\Scripts\python.exe evaluation/validate_h2_h3_review_drafts.py
.\.venv\Scripts\python.exe data/scripts/build_h2_h3_review_drafts.py
```

`validation.json` ghi kết quả kiểm tra và SHA-256 hai file tổng; `human_authorship_requirement_met` vẫn là **false**. Builder chỉ ghi trong thư mục bản nháp này; chạy lại sẽ ghi đè các file nháp và phần riêng, vì vậy cần lưu bản riêng trước khi sửa tay.

## Bộ người viết chính thức

Không đặt các file này vào `data/eval/v4/human/` hoặc đổi `author` thành tên thành viên để coi là dữ liệu người viết. Việc duyệt, dịch hay diễn đạt lại bản nháp AI không biến nó thành bộ do người viết độc lập theo yêu cầu đã nêu.

Để có bộ chính thức, các thành viên tự nghĩ và viết các tình huống độc lập, rồi ghi đúng tên người thực sự viết trong `author` tại hai đường dẫn `data/eval/v4/human/attack_scenarios_vi.jsonl` và `data/eval/v4/human/friction_flows.jsonl`. Có thể tham khảo tên trường và bảng phân bổ chỉ tiêu, giữ nguyên nguyên tắc không chỉnh văn bản theo kết quả firewall. Bản AI này được giữ riêng để đối chiếu, không thay thế bộ chính thức.
